sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("zcontractual.controller.Master", {
		onInit: function() {
		      this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		      this.oRouter.getRoute("Master").attachMatched(this._onRouteMatched, this);
		      debugger;
		    },
		    OnCreate:function() {
		    	var oController = this;
		    	debugger;
		    	this.oRouter.navTo("Detail",{
		    		action: 'Action'
		    	},true);
		    }
	});
});