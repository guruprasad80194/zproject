sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
], function(Controller, MessageBox) {
	"use strict";
	var ColArr = [];
	var CellArr = [];
	var index = " ";
	var indexes;
	return Controller.extend("zcontractual.controller.Detail", {
		onInit: function() {
		      this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		      this.oRouter.getRoute("Detail").attachMatched(this._onRouteMatched, this);
		     // this.getView().byId("id_DetailPage").setVisible(false); 
		    },
		    

		    _onRouteMatched: function(oEvent) {	
		    	var vName = oEvent.getParameter("name");
				  if (vName === "Detail") {
		    	  /*  this.fnLoadColumns();
		    	    this.fnLoadCells();*/
				  }
		        
		    },
		    
		  //Load Columns
		    fnLoadColumns:function(){		
		    	var oTable = this.getView().byId("id_table");
				  ColArr.push('Agency Code');
				  ColArr.push('Agreement No');
				  ColArr.push('Category');
				  ColArr.push('Role');
				  ColArr.push('Employe ID-Mahindra');
				  ColArr.push('Employee ID-Agency');
				  ColArr.push('Employee Name');
				  var i;
				  for (i = 0; i < ColArr.length; i++) {
					/*	var oColumn = new sap.m.Column("col" + i, {*/
					  var oColumn = new sap.m.Column({
							width: "1em",
							header: new sap.m.Label({
							text: ColArr[i]
							})
						});
					  oTable.addColumn(oColumn);
					}	
		    },
		    
		    //Add Cells
		    fnLoadCells:function(){
		    	var oTable = this.getView().byId("id_table");
		    	var i;
		    	for (i = 0; i < ColArr.length; i++) {
	                if (i === 0) {
	                var cell1 = new sap.m.Text({
	                                text: "QuestionTx"
	                                });
	                }
	                CellArr.push(cell1);
		      }
		    	var aColList = new sap.m.ColumnListItem("aColList", {
		            cells: CellArr
		         });
		    	oTable.bindItems("aColList", aColList);
		    },
		    
		    //Change Columns
		    fnChangeColumns:function(){
		    	
		    	
		    },
		    
///	    Add      ///
		    
		    //Opens Add Fragment
		    OnAdd:function(oEvent) {
		    	if (!this.oAdd) {
		            this.oAdd = sap.ui.xmlfragment(
		              "zcontractual.fragments.Add",
		              this
		            );
		            this.getView().addDependent(this.oAdd);
		          }
		          this.oAdd.open();
		    },
		    
		    //Close Fragment
		    OnPressClose:function() {
		    	sap.ui.getCore().byId("id_Agencycode").setValue("");
				sap.ui.getCore().byId("id_Agreement").setValue("");
				sap.ui.getCore().byId("id_Category").setValue("");
				sap.ui.getCore().byId("id_Role").setValue("");
				sap.ui.getCore().byId("id_EmployeeID").setValue("");
				sap.ui.getCore().byId("id_EmployeeAgency").setValue("");
				sap.ui.getCore().byId("id_EmployeeName").setValue("");
				sap.ui.getCore().byId("id_Plant").setValue("");
				sap.ui.getCore().byId("id_BasicAmount").setValue("");
				sap.ui.getCore().byId("id_AgencyCharges").setValue("");
				sap.ui.getCore().byId("id_TotalAmount").setValue("");
				sap.ui.getCore().byId("id_CostCenter").setValue("");
				sap.ui.getCore().byId("id_GST").setValue("");
				sap.ui.getCore().byId("id_HSN").setValue("");
				sap.ui.getCore().byId("id_HRApprovername").setValue("");
			/*	var StartDate = sap.ui.getCore().byId("id_StartDate").getValue();
				var EndDate = sap.ui.getCore().byId("id_EndDate").getValue();*/
		    	this.oAdd.close();
		    },
		    
			// Adding
			fnAddItem: function(oEvent) {
				var oControl = this;
				var Agencycode = sap.ui.getCore().byId("id_Agencycode").getValue();
				var Agreement = sap.ui.getCore().byId("id_Agreement").getValue();
				var Category = sap.ui.getCore().byId("id_Category").getValue();
				var Role = sap.ui.getCore().byId("id_Role").getValue();
				var EmployeeID = sap.ui.getCore().byId("id_EmployeeID").getValue();
				var EmployeeAgency = sap.ui.getCore().byId("id_EmployeeAgency").getValue();
				var EmployeeName = sap.ui.getCore().byId("id_EmployeeName").getValue();
				var Plant = sap.ui.getCore().byId("id_Plant").getValue();
				var BasicAmount = sap.ui.getCore().byId("id_BasicAmount").getValue();
				var AgencyCharges = sap.ui.getCore().byId("id_AgencyCharges").getValue();
				var TotalAmount = sap.ui.getCore().byId("id_TotalAmount").getValue();
				var CostCenter = sap.ui.getCore().byId("id_CostCenter").getValue();
				var GST = sap.ui.getCore().byId("id_GST").getValue();
				var HSN = sap.ui.getCore().byId("id_HSN").getValue();
				var HRApprovername = sap.ui.getCore().byId("id_HRApprovername").getValue();
				var StartDate = sap.ui.getCore().byId("id_StartDate").getValue();
				var EndDate = sap.ui.getCore().byId("id_EndDate").getValue();
				
			if(Agencycode !== "" || Agreement!== "" || Category !== "" || Role !== "" || EmployeeID !== "" || EmployeeAgency !== "" 
				|| EmployeeName !== "" || Plant !== "" || BasicAmount !== "" || AgencyCharges !== "" || TotalAmount !== "" 
				|| CostCenter !== "" || GST !== "" || HSN !== "" || HRApprovername !== "" || StartDate !== "" || EndDate !== "")
			{
				var oLocalData = oControl.getView().getModel("TabJson");
				var sl;
				if (oLocalData) {
					var length = oControl.getView().getModel("TabJson").getData().data.length;
					oLocalData = oControl.getView().getModel("TabJson").getData();
					length++;
					oLocalData.data.push({
						Agency: Agencycode,
						Agreement: Agreement,
						Category: Category,
						Role: Role,
						EmployeeID: EmployeeID,
						EmployeeAgency : EmployeeAgency,
						EmployeeName : EmployeeName,
						Plant : Plant,
						BasicAmount : BasicAmount,
						AgencyCharges : AgencyCharges,
						TotalAmount : TotalAmount,
						CostCenter : CostCenter,
						GST : GST,
						HSN : HSN,
						HRApprovername : HRApprovername,
						StartDate : StartDate,
						EndDate : EndDate
					})
				} else {
					sl = 1;
					if (sl > 0) {
						var oLocalData = {
							"data": [{
								"Agency": Agencycode,
								"Agreement": Agreement,
								"Category": Category,
								"Role": Role,
								"EmployeeID": EmployeeID,
								"EmployeeAgency" : EmployeeAgency,
								"EmployeeName": EmployeeName,
								"Plant" : Plant,
								"BasicAmount" : BasicAmount,
								"AgencyCharges" : AgencyCharges,
								"TotalAmount" : TotalAmount,
								"CostCenter" : CostCenter,
								"GST" : GST,
								"HSN" : HSN,
								"HRApprovername" : HRApprovername,
								"StartDate" : StartDate,
								"EndDate" : EndDate
							}]
						}

					}
				}

				var TabJson = new sap.ui.model.json.JSONModel();
				TabJson.setData(oLocalData);
				oControl.getView().setModel(TabJson, "TabJson");
				
			}
				oControl.OnPressClose();

			},
	
/// Personalize///
			
			// Open Fragment
			onPersonalize:function(oEvent) {
				if (!this.onPersonal) {
		            this.onPersonal = sap.ui.xmlfragment(
		              "zcontractual.fragments.Personalize",
		              this
		            );
		            this.getView().addDependent(this.onPersonal);
		          }
		          this.onPersonal.open();
			},
			
			//Submit
			PressSubmit:function(){
				this.onPersonal.close();
			},
			
			//Close Fragment
		    OnClose:function(){
		    	this.onPersonal.close();
		    },
			
			// Testing Dynamic Columns
		    
			fnSubmit:function(oEvent){
				var Agentcode = sap.ui.getCore().byId("id_Agreement_No").getSelected();
				var Agreement = sap.ui.getCore().byId("id_Agreement_No").getSelected();
				var oController = this; 
				var oTable = this.getView().byId("id_table");
				var Arr = [];
				var Bollean;
				Arr = ColArr;
				var i;
				var j;
				var k;
								
				for(j = 0; j < ColArr.length ; j++){
					if(ColArr[j] == "Agency Code"){
					if(Agentcode == false )
					{
						if(ColArr[j] == "Agency Code"){
							ColArr.splice(j,1)
						}
					}
					else if( Agentcode == true)
					{					
					oController.Bollean = ColArr.includes("Agency Code")
						if(oController.Bollean == false){
					    ColArr.splice(0,0,"Agency Code");	
						}
					}
				}
					else if(ColArr[j] == "Agreement No"){
						if(Agreement == false )
						{
							if(ColArr[j] == "Agreement No"){
								ColArr.splice(j,1)
							}
						}
						else if( Agreement == true)
						{					
						oController.Bollean = ColArr.includes("Agreement No")
							if(oController.Bollean == false){
						    ColArr.splice(1,0,"Agreement");	
							}
						}
				
			}	
				}
				
				oTable.removeAllColumns();
				
				  for (i = 0; i < ColArr.length; i++) {
						var oColumn = new sap.m.Column( {
							width: "1rem",
							header: new sap.m.Label({
							text: ColArr[i]
							})
						});
					  oTable.addColumn(oColumn);
					}	
				
				this.onPersonal.close();
				
			},
			onSelectionChange:function(oEvent){
				var oSelectedItem = oEvent.getParameter("listItem");
				var oModel = oSelectedItem.getBindingContext().getObject();
			},
			
///  Edit Row From Table   ///
			
			// OpenEdit Fragment
			onPressEdit:function(oEvent)
			{
				debugger;
				var arrcount;
				arrcount = oEvent.mParameters.id.split("-");
				index = arrcount[7];
				var TabJson = this.getView().getModel("TabJson").getData();
				var FormJson = new sap.ui.model.json.JSONModel();
				FormJson.setData(TabJson.data[index]);
				this.getView().setModel(FormJson, "FormJson");
				
				if (!this.oEdit) {
		            this.oEdit = sap.ui.xmlfragment(
		              "zcontractual.fragments.Edit",
		              this
		            );
		            this.getView().addDependent(this.oEdit);
		          }
		          this.oEdit.open();
			},
			
			// CloseEdit Fragment
			OnCloseEdit:function(){
				debugger;
				 this.oEdit.close();
			},
			
			// SubmitEdit Fragment
			onOkEdit:function(){
				debugger;
/*				var oControl = this;
				var Agencycode = sap.ui.getCore().byId("id_ed_Agency").getValue();
				var Agreement = sap.ui.getCore().byId("id_ed_Agreement").getValue();
				var Category = sap.ui.getCore().byId("id_ed_category").getValue();
				var Role = sap.ui.getCore().byId("id_ed_role").getValue();
				var EmployeeID = sap.ui.getCore().byId("id_ed_emploeeid").getValue();
				var EmployeeAgency = sap.ui.getCore().byId("id_ed_employeeagency").getValue();
				var EmployeeName = sap.ui.getCore().byId("id_ed_Ename").getValue();
				var Plant = sap.ui.getCore().byId("id_ed_Plant").getValue();
				var BasicAmount = sap.ui.getCore().byId("id_ed_bamt").getValue();
				var AgencyCharges = sap.ui.getCore().byId("id_ed_Agencycharges").getValue();
				var TotalAmount = sap.ui.getCore().byId("id_ed_totalamt").getValue();
				var CostCenter = sap.ui.getCore().byId("id_ed_cc").getValue();
				var GST = sap.ui.getCore().byId("id_ed_gst").getValue();
				var HSN = sap.ui.getCore().byId("id_ed_hsn").getValue();
				var HRApprovername = sap.ui.getCore().byId("id_ed_hrapprover").getValue();
				var StartDate = sap.ui.getCore().byId("id_ed_start").getValue();
				var EndDate = sap.ui.getCore().byId("id_ed_end").getValue();*/
				this.getView().getModel("TabJson").refresh(true);
				this.oEdit.close();
				
			},
			
/// Delete Row From Table ///
			
		onPressdelete: function(oEvent){
				debugger;
				var arrcount;
				arrcount = oEvent.mParameters.id.split("-");
				indexes = arrcount[7];
				
				if (!this.oDelete) {
		            this.oDelete = sap.ui.xmlfragment(
		              "zcontractual.fragments.Delete",
		              this
		            );
		            this.getView().addDependent(this.oDelete);
		          }
		          this.oDelete.open();
/*				MessageBox.confirm("Are you sure you want to delete??", {
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
					emphasizedAction: MessageBox.Action.OK,
					onClose: function (sAction) {
						if(sAction == "CANCEL"){
						
						}
					}
				});*/
			},
			
			OnCancel:function(oEvent){
				this.oDelete.close();
			},
			
			// On Press Delete Button
			fndeleteItem:function(oEvent){
				debugger;
				var arr = this.getView().byId("id_table").getModel("TabJson").getData().data;
				arr.splice(indexes,1);
				this.getView().byId("id_table").getModel("TabJson").refresh(true);
				this.OnCancel();
			},
			
			// On Press More Button
			onPressmore:function(oEvent)
			{
				debugger;
				var arrcount;
				arrcount = oEvent.mParameters.id.split("-");
				index = arrcount[7];
				var TabJson = this.getView().getModel("TabJson").getData();
				var FormJson = new sap.ui.model.json.JSONModel();
				FormJson.setData(TabJson.data[index]);
				this.getView().setModel(FormJson, "FormJson");
				
				if (!this.oMore) {
		            this.oMore = sap.ui.xmlfragment(
		              "zcontractual.fragments.More",
		              this
		            );
		            this.getView().addDependent(this.oMore);
		          }
		          this.oMore.open();
			},
			
			OnCloseMore:function(oEvent){
				this.oMore.close();
			},
			
/// Upload File Attachment ///	
			
			handleUploadComplete: function(oEvent) {
				var sResponse = oEvent.getParameter("response");
				if (sResponse) {
					var sMsg = "";
					var m = /^\[(\d\d\d)\]:(.*)$/.exec(sResponse);
					if (m[1] == "200") {
						sMsg = "Return Code: " + m[1] + "\n" + m[2] + "(Upload Success)";
						oEvent.getSource().setValue("");
					} else {
						sMsg = "Return Code: " + m[1] + "\n" + m[2] + "(Upload Error)";
					}

					MessageToast.show(sMsg);
				}
			},
			
			handleUploadPress: function(oEvent) {
				var oFileUploader = this.getView().byId("fileUploader");
				oFileUploader.upload();
			},
			
// Upload Collection Code	//		
		    fnChange: function(oEvent) {
		      var oModel = this.getView().getModel();
		      aPath.push(oEvent.getSource()._oFileUploader.oFileUpload.files[0]);
		      var oUploadCollection = oEvent.getSource();
		      // Header Token
		      var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
		        name: "x-csrf-token",
		        value: oModel.getSecurityToken()
		      });
		      oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
		    },
		    
		    fnBeforeUploadStarts: function(oEvent) {
		      // Header Slug
		      var vSlug = this.Trid + "$" + oEvent.getParameter("fileName");
		      var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
		        name: "slug",
		        value: vSlug
		      });
		      oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);
		    },
		    
		    fnStartUpload: function(oEvent) {
		      var oUploadCollection = sap.ui.getCore().byId("id_UploadCollection");
		      oUploadCollection.upload();
		      this.oRemark.close();
		    },
		    
		    fnUploadComplete: function(oEvent) {
		      var sUploadedFileName = oEvent.getParameter("files")[0].fileName;
		      var vValue = "";
		      setTimeout(function() {
		        var oUploadCollection = sap.ui.getCore().byId("id_UploadCollection");
		        for (var i = 0; i < oUploadCollection.getItems().length; i++) {
		          if (oUploadCollection.getItems()[i].getFileName() === sUploadedFileName) {
		            vValue = oUploadCollection.getItems()[i].getFileName() + " Uploaded Successfully";
		            sap.m.MessageToast.show(vValue);
		            oUploadCollection.removeItem(oUploadCollection.getItems()[i]);
		            break;
		          }
		        }
		      }.bind(this), 2000);
		    },
		    
		    fnFileDeleted: function(oEvent) {
		      sap.m.MessageToast.show("Event fileDeleted triggered");
		    },
		    
		    fnSelectionChange: function(oEvent) {
		      var vStart = oEvent.mParameters.selectedItems[0].mAggregations.attributes[0].sId.lastIndexOf("e") + 1;
		      var vEnd = oEvent.mParameters.selectedItems[0].mAggregations.attributes[0].sId.length;
		      this.vSelectU = oEvent.mParameters.selectedItems[0].mAggregations.attributes[0].sId.substr(vStart, vEnd);
		      if (this.vSelectU != this.vSelectI) { // selection change event is firing depend on no of items so taking only one time
		        this.vSelectI = this.vSelectU;
		        sap.m.URLHelper.redirect(encodeURI(URL.createObjectURL(this.oPath[this.vSelectU])), true);
		      }
		    }

	});
});